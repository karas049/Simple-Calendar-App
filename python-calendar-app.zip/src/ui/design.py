from tkinter import Tk, Frame, Label, Button, messagebox
from datetime import datetime
import calendar

class CalendarApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Python Calendar App")
        self.master.geometry("600x600")
        
        self.current_month = datetime.now().month
        self.current_year = datetime.now().year
        
        self.create_widgets()
        self.display_calendar()

    def create_widgets(self):
        self.header_frame = Frame(self.master)
        self.header_frame.pack()

        self.prev_button = Button(self.header_frame, text="Previous", command=self.prev_month)
        self.prev_button.pack(side="left")

        self.next_button = Button(self.header_frame, text="Next", command=self.next_month)
        self.next_button.pack(side="right")

        self.calendar_frame = Frame(self.master)
        self.calendar_frame.pack()

    def display_calendar(self):
        for widget in self.calendar_frame.winfo_children():
            widget.destroy()

        month_calendar = calendar.monthcalendar(self.current_year, self.current_month)
        month_name = calendar.month_name[self.current_month]
        year_label = Label(self.calendar_frame, text=f"{month_name} {self.current_year}", font=("Helvetica", 16))
        year_label.grid(row=0, column=0, columnspan=7)

        for row_index, week in enumerate(month_calendar):
            for col_index, day in enumerate(week):
                if day != 0:
                    day_button = Button(self.calendar_frame, text=str(day), command=lambda d=day: self.show_event(d))
                    day_button.grid(row=row_index + 1, column=col_index, padx=5, pady=5)

    def show_event(self, day):
        event_date = f"{self.current_year}-{self.current_month:02d}-{day:02d}"
        messagebox.showinfo("Event", f"Events for {event_date}")

    def prev_month(self):
        if self.current_month == 1:
            self.current_month = 12
            self.current_year -= 1
        else:
            self.current_month -= 1
        self.display_calendar()

    def next_month(self):
        if self.current_month == 12:
            self.current_month = 1
            self.current_year += 1
        else:
            self.current_month += 1
        self.display_calendar()

def main():
    root = Tk()
    app = CalendarApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()